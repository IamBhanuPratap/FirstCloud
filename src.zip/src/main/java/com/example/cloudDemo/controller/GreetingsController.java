package com.example.cloudDemo.controller;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import com.example.cloudDemo.response.HelloResponse;
import com.example.cloudDemo.service.Greeting;

@RestController
public class GreetingsController {
	private Greeting greetingService;
	public HelloResponse greetResponse ;
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Path("/{greetings}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public ResponseEntity greetings(@PathParam(value = "greetings") String greetings, @QueryParam(value = "name") String name) {
		greetResponse = greetingService.greetingResponse(greetings,name);
		return new ResponseEntity(greetResponse,HttpStatus.OK);
	}

}
