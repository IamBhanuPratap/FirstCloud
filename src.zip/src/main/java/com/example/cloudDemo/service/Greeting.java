package com.example.cloudDemo.service;

import com.example.cloudDemo.response.HelloResponse;

public interface Greeting {

	
	public HelloResponse greetingResponse(String greetings,String name);
}
